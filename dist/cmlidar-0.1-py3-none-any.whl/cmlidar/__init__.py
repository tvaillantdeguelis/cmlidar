'''
cmlidar is a package to help standardize colormaps for commonly-plotted
cloud and aerosol lidar properties.
'''

from . import cm
 